const mysqli = require('mysql');

const conn = mysqli.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"education_khoj"
})


conn.connect((err)=>{
    if(err)throw err;
    console.log('connection succ !')
})


module.exports = conn; 