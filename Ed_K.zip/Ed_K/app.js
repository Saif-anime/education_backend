const express = require('express')
const app = express();
const path = require('path');
const hbs = require('hbs');
const port = 8000;
const multer = require('multer');
const mysqli = require('mysql')

const conn = require('./conn')


const views = path.join(__dirname, "/views/template");
const partials = path.join(__dirname, "/views/partials");


app.use(express.urlencoded({ extended: true }));

app.set('views', views);
app.set('view engine', 'hbs');
hbs.registerPartials(partials)

app.use(express.static(path.join(__dirname, 'static')))

app.use(express.json())


app.get('/', (req, res) => {
    res.render('Home')
})


app.get('/news', (req, res) => {
    res.render('News')
})

app.get('/job', (req, res) => {
    res.render('Job')
})

app.get('/interview', (req, res) => {
    res.render('Interview')
})

app.get('/contact', (req, res) => {
    res.render('Contact')
})



app.get('/login', (req, res) => {
    res.render('Login')
})


app.get('/Sign', (req, res) => {
    res.render('Sign')
})




// sign up here 
app.post('/Sign', (req, res) => {
    const { name, email, pass, cpass } = req.body;
    let read = `SELECT * FROM ragister WHERE Email='${email}'`;
    conn.query(read, (err, result) => {
        if (err) throw err;
        if (!read) {
            if (pass == cpass) {
                let insert = `INSERT INTO ragister( Name, Email, Password) VALUES ('${name}','${email}','${pass}')`;
                conn.query(insert, (err, result) => {
                    if (err) throw err;
                    res.status(201).send("Sign in completed !")
                })
            } else {
                res.status(401).send("sign up not succ full !");
            }
        } else {
            res.status(401).send("email is already exist please login");
        }
    })

})




// login here 
app.post('/login', (req, res) => {
    const { email, pass } = req.body;
    let read = `SELECT * FROM ragister WHERE Email='${email}'`;
    conn.query(read, (err, result) => {
        if (err) throw err;
        if (read) {
            if (result[0].Password == pass) {
                res.status(201).send('login succ!');
            } else {
                res.status(401).send('invalid details');
            }
        } else {
            res.status(401).send('invalid details');
        }
    })
})

const upload = multer({
    storage: multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, "uploads")
        },
        filename: function (req, file, cb) {
            cb(null, "/" + file.fieldname + "-" + Date.now() + ".jpg")
        }
    })
})



// admin news 

app.post('/admin/news', upload.single('img'), (req, res) => {
    const { title, author, tags, category, desc } = req.body;
    const img = req.file;
    let insert = `INSERT INTO news(title, img, author, tags, category, news_desc) VALUES ('${title}','uploads${img.filename}','${author}','${tags}','${category}','${desc}')`;
    conn.query(insert, (err, result) => {
        if (err) throw err;
        res.status(201).send("News Detail submitted !")
    })
})


// admin interview 







// admin job 










app.listen(port, () => {
    console.log('my server run is port no.' + port);
})